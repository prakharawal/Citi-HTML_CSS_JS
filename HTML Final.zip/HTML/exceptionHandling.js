function validationFunction() {
    var message;
    var num;

    message = document.getElementById("message");
    message.innerHTML = "";

    num = document.getElementById("txtNumber").value;

    try {
        if(num == "") throw "is empty";

        if(isNaN(num)) throw "is not a number";

        num = Number(num);

        if(num > 10) throw "is too high";

        if(num < 5) throw "is too low";
    } catch (error) {
        message.innerHTML = "Input " + error;
    }
    finally {
        document.getElementById("message").value = "";
    }
}