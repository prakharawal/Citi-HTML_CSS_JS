function lightOn() {
    document.getElementById("bulbImage").src = "bulbon.gif"
}

function lightOff() {
    document.getElementById("bulbImage").src = "bulboff.gif"
}