var person = {
    fname: "Vivek", lname: "Gohil", age: 31
};
var text = "";
var temp;

for (temp in person) {
    text = text  + person[temp] + " ";
    console.log("Key :: " + temp);
    console.log("Value :: " + person[temp]);
    console.log("______________________________________");
}

document.getElementById("demo").innerHTML = text;
