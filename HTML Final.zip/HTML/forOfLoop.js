var data = "javascript";
var result = "";
for (x of data) {
    result += x + "<br/>";
}
document.getElementById('demo1').innerHTML = result;

result = "";
for (x of data) {
    if (x != 'a' && x != 'e' && x != 'i' && x != 'o' && x != 'u')
        result += x + "<br/>";
}

document.getElementById('demo2').innerHTML = result;

// print "JavaScript" string each char in new line.

// J
// a
// v
// a
// S
// c
// r
// i
// p
// t

// ------------------------------

// remove vowels from the given string and print the text
//if