function displayDate() {
    document.getElementById("demo").innerHTML = Date();
}

document.getElementById("dateButton").onclick = displayDate;