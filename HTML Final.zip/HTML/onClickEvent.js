function changeText(id){
    id.innerHTML = "Ooops!";
}