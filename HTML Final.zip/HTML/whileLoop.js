var number = prompt("Enter Number");
var text = "";
var i = 1;
// while(i < 11) {
//     text = text + number + " * "+ i +  " = " + number *i + "<br>";
//     i++;
// }
do {
    text = text + number + " * " + i + " = " + number * i + "<br>";
    i++;
}
while(i < 11);
document.getElementById("demo").innerHTML = text;