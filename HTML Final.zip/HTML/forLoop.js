var number = prompt("Enter Number");
var text = "";
var i;
for (i = 1; i < 11; i++) {
    text = text + number + " * "+ i +  " = " + number *i + "<br>";
}
document.getElementById("demo").innerHTML = text;

// Accept number from user and print the multiplication table
// Example

// number = 9

// 9 * 1 = 9
// 9 * 2 = 18
// 9 * 3 = 27
// ....
// 9 * 10 = 90