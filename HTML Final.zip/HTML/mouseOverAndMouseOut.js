
function forMouseOver(obj) {
    obj.innerHTML = "Thank you !"    
}
function forMouseOut(obj) {
    obj.innerHTML = "Mouse Over Me"    
}