//Function Expression
var sum = function (a, b) {
    return a + b;
}

document.getElementById("demo").innerHTML = "Result is  " + sum(4, 5);