function myFunction(a , b){
    return a + b;
}

var result = myFunction(4,5);
document.getElementById("demo").innerHTML =  "Result is " + result ;