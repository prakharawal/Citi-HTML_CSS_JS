var result = (x , y) => { return x * y};

document.getElementById("demo").innerHTML = "Result is :: " + result(4,5);