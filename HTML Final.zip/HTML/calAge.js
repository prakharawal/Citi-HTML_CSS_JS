var age =prompt("What is your age");
var days = age * 365.25;
alert(age + "years is roughly "+ days + " days");