function myFunction() {
    var name = document.getElementById("fName");
    name.value = name.value.toUpperCase();
}

function test() {
    alert("Welcome to JavaScript Events !!");
}