// var result = new Function( "a" , "b" , "return a * b" );
// document.getElementById("demo").innerHTML = result(4,5);

(function() {
    document.getElementById("demo").innerHTML = "Hello! I called myself";
})();